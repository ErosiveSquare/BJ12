import numpy as np
import pandas as pd


def generate_realistic_price_forecast():
    """
    生成符合实际的日前电价预测数据

    特征：
    1. 24小时，每小时4个时段（共96个时段）
    2. 模拟真实的电价波动模式（元/MWh）
    3. 包含明显的早晚高峰、午间低谷和夜间低谷
    4. 工作日与周末模式差异
    """
    # 设置随机种子以便复现
    np.random.seed(42)

    # 基础电价（元/MWh）
    base_price = 350

    # 时段权重 - 更符合实际电价波动模式（元/MWh）
    # 典型特征：早高峰(8-11点)，午间低谷(12-14点)，晚高峰(17-21点)，夜间低谷(23-5点)
    hourly_weights = [
        0.45, 0.40, 0.38, 0.35,  # 0-4点 深夜低谷
        0.40, 0.45, 0.70, 0.95,  # 4-8点 清晨逐渐上升
        1.25, 1.35, 1.40, 1.30,  # 8-12点 早高峰
        1.10, 1.00, 0.95, 0.90,  # 12-16点 午间回落
        1.05, 1.25, 1.50, 1.60,  # 16-20点 晚高峰
        1.35, 1.10, 0.80, 0.60  # 20-24点 夜间下降
    ]

    # 生成96个时段的电价
    prices = []
    for hour, weight in enumerate(hourly_weights):
        # 每小时4个时段，增加波动性
        for quarter in range(4):
            # 高峰时段波动性更大
            volatility = 0.12 if weight > 1.2 else 0.08

            # 添加日内波动模式
            intra_hour_variation = 0.02 * (quarter - 1.5)  # 每小时内的小波动

            price = base_price * (weight + intra_hour_variation) * (1 + np.random.normal(0, volatility))

            # 确保价格在合理范围内 (100-800元/MWh)
            price = max(min(price, 800), 100)
            prices.append(round(price, 2))

    # 创建DataFrame
    df = pd.DataFrame({
        'timestamp': pd.date_range(start='2025-01-01', periods=96, freq='15T'),
        'price': prices
    })

    # 添加周循环模式（工作日更高）
    df['day_of_week'] = df['timestamp'].dt.dayofweek
    df.loc[df['day_of_week'] >= 5, 'price'] = df['price'] * 0.85  # 周末降价15%

    # 保存CSV
    df.to_csv('realistic_price_forecast.csv', index=False)
    print("符合实际的电价预测数据已生成：realistic_price_forecast.csv")

    return df


# 生成并展示数据
price_data = generate_realistic_price_forecast()
print(price_data.head(10))
print("\n电价统计信息：")
print(price_data['price'].describe())
print("\n高峰时段示例（8:00-20:00）：")
print(price_data.iloc[32:80:4])  # 展示每个整点的价格