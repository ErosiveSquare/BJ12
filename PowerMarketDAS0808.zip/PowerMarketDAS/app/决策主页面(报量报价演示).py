# streamlit run app/决策主页面(报量报价演示).py

import streamlit as st
import pandas as pd
import sys
import os
import pyomo.environ as pyo
import plotly.graph_objects as go
from datetime import datetime

# --- 关键路径处理 ---
# 这个代码块是解决 app 和 utils 是同级目录问题的核心。
# 它将项目的根目录添加到Python的搜索路径中。
try:
    # 获取当前文件的目录 (your_project_root/app)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 获取项目根目录 (your_project_root)
    project_root = os.path.abspath(os.path.join(current_dir, '..'))
    # 如果项目根目录不在sys.path中，则添加它
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    # 现在可以安全地从同级目录导入模块了
    from models.optimization_model import FlowBatteryDayAheadMarketModel, mode_selection_rarr, generate_bid_table, \
        generate_segmented_bid_table, calculate_kpis
    from models.parameter_config import get_default_battery_params, validate_battery_params
    from utils.visualization import generate_comprehensive_visualization
    from utils.database import init_db, save_decision_record, load_station_profile

except (ImportError, NameError) as e:
    st.error(f"模块导入失败: {e}")
    st.error(f"请确保您的项目结构正确，且依赖已安装。期望的结构是 'app' 和 'utils'/'models' 文件夹位于同一项目根目录下。")


    # 提供一个备用方案，以便UI可以渲染，避免应用完全崩溃
    def get_default_battery_params():
        return {}


    def validate_battery_params(p):
        return p


    class FlowBatteryDayAheadMarketModel:
        def __init__(self, *args, **kwargs): pass

        def solve_model(self): return None, None


    def mode_selection_rarr(*args, **kwargs):
        return 1


    def generate_segmented_bid_table(*args, **kwargs):
        return pd.DataFrame(columns=['时段', '类型', '分段', '申报电量(MWh)', '申报电价(元/MWh)'])


    def generate_bid_table(*args, **kwargs):
        return pd.DataFrame()


    def calculate_kpis(*args, **kwargs):
        return {k: 0 for k in ['总净利润', '总放电收益', '等效循环次数', '总能量吞吐', '平均度电利润']}


    def generate_comprehensive_visualization(*args, **kwargs):
        return go.Figure()


    def init_db():
        pass


    def save_decision_record(*args, **kwargs):
        pass


    def load_station_profile():
        return {'e_rated': 100, 'p_rated': 25}


@st.cache_data
def convert_df_to_csv(df):
    """将DataFrame转换为CSV格式的字符串，以便下载。"""
    if not isinstance(df, pd.DataFrame):
        df = pd.DataFrame(df)
    return df.to_csv(index=False).encode('utf-8-sig')


def create_results_dataframe(model, price_forecast, battery_params, time_step_minutes):
    """从Pyomo模型中提取数据并创建详细结果的DataFrame。"""
    if model is None:
        return pd.DataFrame()

    T = len(price_forecast)
    charge_power = [pyo.value(model.P_charge[t]) for t in range(T)]
    discharge_power = [pyo.value(model.P_discharge[t]) for t in range(T)]
    net_power = [dp - cp for dp, cp in zip(discharge_power, charge_power)]
    energy = [pyo.value(model.E[t]) for t in range(T)]
    soc = [e / battery_params['E_rated'] * 100 for e in energy]

    time_index = pd.to_datetime(pd.date_range(start='2023-01-01', periods=T, freq=f'{time_step_minutes}T'))

    results_df = pd.DataFrame({
        'Time': time_index.strftime('%H:%M'),
        'Price (元/MWh)': price_forecast,
        'Charge_Power (MW)': charge_power,
        'Discharge_Power (MW)': discharge_power,
        'Net_Power (MW)': net_power,
        'Energy_State (MWh)': energy,
        'SOC (%)': soc
    })
    return results_df


def display_battery_params(battery_params):
    """展示所有技术参数"""
    st.sidebar.header("🔍 参数概览")
    param_groups = {
        "额定参数": ['E_rated', 'P_rated'], "能量参数": ['E_0', 'E_T_target', 'initial_soc'],
        "效率参数": ['η_charge', 'η_discharge'], "SOC参数": ['SOC_min', 'SOC_max'],
        "循环与退化": ['N_cycle_max', 'k'], "运维成本": ['C_OM'], "功率爬坡": ['R_ramp'],
    }
    for group, params in param_groups.items():
        with st.sidebar.expander(group, expanded=False):
            for param in params:
                st.write(f"{param}: {battery_params.get(param, 'N/A')}")


def main():
    st.set_page_config(page_title="优化决策仪表盘", layout="wide", initial_sidebar_state="expanded")

    # 在应用启动时初始化数据库
    # init_db()

    st.title("🔋 液流电池储能电站 - 优化决策仪表盘")
    st.markdown("上传日前电价预测，配置储能参数，系统将为您提供最优的充放电计划和市场申报策略。")

    # --- 输入参数配置 ---
    with st.container(border=True):
        st.subheader("⚙️ 参数配置")
        st.markdown("---")
        tab1, tab2, tab3 = st.tabs(["🖥️ **系统配置**", "🔋 **电池参数**", "📈 **市场参数**"])

        # 从数据库加载档案，以更新默认值
        station_profile = load_station_profile()
        default_params = get_default_battery_params()
        if station_profile:
            default_params['E_rated'] = station_profile.get('e_rated', default_params.get('E_rated', 100))
            default_params['P_rated'] = station_profile.get('p_rated', default_params.get('P_rated', 25))

        battery_params = default_params.copy()

        with tab1:
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("###### 求解器与时间")
                solver_type = st.selectbox("求解器选择", ["CBC", "IPOPT"], label_visibility="collapsed")
            with col2:
                st.markdown("###### ")
                time_horizon = st.number_input("优化时间范围 (小时)", 1, 48, 24, label_visibility="collapsed")
            st.markdown("###### ")
            time_step = st.number_input("时间步长 (分钟)", 1, 60, 15)

        with tab2:
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("###### 核心规格")
                battery_params['E_rated'] = st.number_input('额定容量 (MWh)', 10, 500,
                                                            int(battery_params.get('E_rated', 100)))
                battery_params['P_rated'] = st.number_input('额定功率 (MW)', 1, 100,
                                                            int(battery_params.get('P_rated', 25)))
                st.markdown("###### 运行状态")
                battery_params['initial_soc'] = st.slider('初始荷电状态 (SOC)', 0.2, 0.8,
                                                          battery_params.get('initial_soc', 0.5), format="%.2f")
                battery_params['E_0'] = st.number_input('初始能量 (MWh)', 1, 500, int(battery_params.get('E_0', 50)))
                battery_params['E_T_target'] = st.number_input('目标结束能量 (MWh)', 1, 500,
                                                               int(battery_params.get('E_T_target', 50)))
            with col2:
                st.markdown("###### 效率参数")
                battery_params['η_charge'] = st.slider('充电效率', 0.7, 1.0, battery_params.get('η_charge', 0.9),
                                                       format="%.2f")
                battery_params['η_discharge'] = st.slider('放电效率', 0.7, 1.0, battery_params.get('η_discharge', 0.9),
                                                          format="%.2f")
                st.markdown("###### SOC 范围")
                battery_params['SOC_min'] = st.slider('最小荷电状态 (SOC)', 0.1, 0.3,
                                                      battery_params.get('SOC_min', 0.2), format="%.2f")
                battery_params['SOC_max'] = st.slider('最大荷电状态 (SOC)', 0.7, 0.9,
                                                      battery_params.get('SOC_max', 0.8), format="%.2f")

        with tab3:
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("###### 成本与退化")
                battery_params['k'] = st.number_input('度电退化成本系数', 0.0, 0.5, battery_params.get('k', 0.01),
                                                      format="%.4f")
                battery_params['N_cycle_max'] = st.number_input('最大等效循环次数', 1, 10,
                                                                int(battery_params.get('N_cycle_max', 5)))
                battery_params['C_OM'] = st.number_input('固定运维成本', 0, 5000, int(battery_params.get('C_OM', 100)))
            with col2:
                st.markdown("###### 物理约束")
                battery_params['R_ramp'] = st.number_input('功率爬坡速率 (MW/15min)', 0.1, 50.0,
                                                           float(battery_params.get('R_ramp', 2.0)))

        display_battery_params(battery_params)

    # --- 文件上传与执行 ---
    uploaded_file = st.file_uploader("上传电价预测数据 (CSV, 包含'price'列)", type=['csv'])
    solve_button = st.button("🚀 开始优化求解", type="primary", use_container_width=True)

    # --- 核心逻辑与结果展示 ---
    if uploaded_file is not None and solve_button:
        try:
            price_forecast = pd.read_csv(uploaded_file)['price'].values
            battery_params = validate_battery_params(battery_params)

            st.markdown("---")
            st.subheader("🚀 优化执行进度看板")
            with st.container(border=True):
                progress_bar_placeholder = st.empty()
                with st.expander("查看详细执行日志", expanded=True):
                    log_container = st.container()

            progress_bar = progress_bar_placeholder.progress(0)
            log_container.info("ℹ️ 优化流程已启动，准备执行...")

            progress_bar.progress(10, text="第一阶段：正在求解最优基准计划...")
            log_container.markdown("⏳ **第一阶段：** 正在求解最优充放电基准计划...")
            market_model = FlowBatteryDayAheadMarketModel(price_forecast, battery_params)
            optimal_model, solve_results = market_model.solve_model()

            if optimal_model is None:
                st.error("优化模型求解失败，无法进行后续步骤。请检查参数和输入数据。")
                log_container.error("❌ **第一阶段失败：** 优化模型求解失败。")
                st.stop()

            progress_bar.progress(40, text="第一阶段完成！")
            log_container.markdown("✅ **第一阶段：** 基准计划求解完成！")

            progress_bar.progress(50, text="第二阶段：正在进行模式决策...")
            log_container.markdown("⏳ **第二阶段：** 正在通过RARR方法进行模式决策 (可能需要一些时间)...")
            with st.spinner('正在进行蒙特卡洛模拟以评估风险...'):
                optimal_mode = mode_selection_rarr(optimal_model, price_forecast, battery_params)
            mode_text = '报量不报价' if optimal_mode == 0 else '报量报价'

            progress_bar.progress(80, text=f"第二阶段完成: {mode_text}")
            log_container.markdown(f"✅ **第二阶段：** 模式决策完成！推荐采用 **{mode_text}** 模式。")

            progress_bar.progress(90, text="第三阶段：正在生成报告和申报策略...")
            log_container.markdown("⏳ **第三阶段：** 正在生成报告和申报策略...")
            kpis = calculate_kpis(optimal_model, price_forecast, battery_params)
            results_df = create_results_dataframe(optimal_model, price_forecast, battery_params, time_step)
            fig = generate_comprehensive_visualization(optimal_model, price_forecast, battery_params)

            # --- 保存记录到数据库 ---
            save_decision_record(kpis, mode_text)
            log_container.info("ℹ️ 本次决策结果已成功存入电站档案。")

            progress_bar.progress(100, text="优化全部完成！")
            log_container.markdown("✅ **第三阶段：** 报告与策略生成完毕！")
            log_container.success("🎉 **全部流程已成功完成！** 请在下方的选项卡中查看详细结果。")

            # --- 结果展示选项卡 ---
            st.markdown("---")
            results_tab1, results_tab2, results_tab3 = st.tabs(
                ["📈 **核心看板**", "📊 **详细调度数据**", "💰 **市场报价策略**"])

            with results_tab1:
                st.header("关键性能指标 (KPIs)")
                kpi_cols = st.columns(5)
                kpi_cols[0].metric("💰 总净利润", f"{kpis['总净利润']:,.2f} 元",
                                   delta=f"{kpis['总放电收益']:,.2f} 元收益")
                kpi_cols[1].metric("💡 总放电收益", f"{kpis['总放电收益']:,.2f} 元")
                kpi_cols[2].metric("🔄 等效循环次数", f"{kpis['等效循环次数']:.3f} 次")
                kpi_cols[3].metric("⚡ 总能量吞吐", f"{kpis['总能量吞吐']:.2f} MWh")
                kpi_cols[4].metric("💡 平均度电利润", f"{kpis['平均度电利润']:.2f} 元/MWh")
                st.header("优化调度策略可视化")
                st.plotly_chart(fig, use_container_width=True)

            with results_tab2:
                st.header("详细调度计划")
                st.markdown("下表展示了每个时间步的详细调度结果。")
                st.dataframe(results_df.style.format({
                    'Price (元/MWh)': '{:.2f}', 'Charge_Power (MW)': '{:.2f}', 'Discharge_Power (MW)': '{:.2f}',
                    'Net_Power (MW)': '{:.2f}', 'Energy_State (MWh)': '{:.2f}', 'SOC (%)': '{:.1f}%'
                }).background_gradient(cmap='viridis', subset=['Price (元/MWh)']), use_container_width=True)
                csv_results = convert_df_to_csv(results_df)
                st.download_button(label="📥 下载详细数据 (CSV)", data=csv_results,
                                   file_name='optimal_schedule_details.csv', mime='text/csv')

            with results_tab3:
                st.header(f"生成的市场报价策略 ({mode_text})")

                optimal_mode = 1 ##强制报量报价

                if optimal_mode == 1:
                    st.markdown("系统决策采用 **报量报价** 模式。下表为分段申报的电量和对应价格。")
                    bid_table = generate_segmented_bid_table(optimal_model, price_forecast, battery_params)
                    if not isinstance(bid_table, pd.DataFrame): bid_table = pd.DataFrame(bid_table)
                    if not bid_table.empty and '类型' in bid_table.columns:
                        st.dataframe(bid_table.style.apply(lambda s: [
                            'background-color: #d4edda' if v == '放电' else 'background-color: #f8d7da' if v == '充电' else ''
                            for v in s], subset=['类型']), use_container_width=True)
                    else:
                        st.dataframe(bid_table, use_container_width=True)
                    csv_bids = convert_df_to_csv(bid_table)
                    st.download_button(label="📥 下载报价策略 (CSV)", data=csv_bids,
                                       file_name='segmented_bidding_strategy.csv', mime='text/csv')
                else:
                    st.markdown("系统决策采用 **报量不报价** 模式。下表为各时段的净功率申报计划（正为放电，负为充电）。")
                    bid_table = generate_bid_table(optimal_model, price_forecast, battery_params)
                    if not isinstance(bid_table, pd.DataFrame): bid_table = pd.DataFrame(bid_table)
                    st.dataframe(bid_table, use_container_width=True)
                    csv_bids = convert_df_to_csv(bid_table)
                    st.download_button(label="📥 下载报价策略 (CSV)", data=csv_bids,
                                       file_name='simple_bidding_strategy.csv', mime='text/csv')

        except Exception as e:
            st.error(f"优化求解或决策过程中出错: {e}")
            st.exception(e)


if __name__ == "__main__":
    main()
