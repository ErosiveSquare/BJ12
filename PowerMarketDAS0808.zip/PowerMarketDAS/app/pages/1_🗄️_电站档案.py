# app/pages/1_🗄️_电站档案.py

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import sys
import os
from datetime import datetime

# 确保可以导入项目根目录下的模块
try:
    # 获取当前文件的目录 (your_project_root/app/pages)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 获取项目根目录 (your_project_root)
    project_root = os.path.abspath(os.path.join(current_dir, '..', '..'))
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    # 导入包含了 init_db 的所有必要函数
    from utils.database import init_db, load_station_profile, save_station_profile, load_decision_records

except ImportError as e:
    st.error(f"无法导入数据库模块: {e}")
    st.error("请确保您的项目结构正确：'app' 和 'utils' 文件夹应位于同一项目根目录下。")
    st.stop()


def display_profile_form(profile):
    """显示用于编辑电站档案的表单"""
    with st.form(key="profile_form"):
        st.subheader("📝 编辑电站档案")
        edited_profile = {}
        col1, col2 = st.columns(2)
        with col1:
            edited_profile['station_name'] = st.text_input("电站名称", value=profile.get('station_name'))
            edited_profile['e_rated'] = st.number_input("额定容量 (MWh)", min_value=1.0,
                                                        value=float(profile.get('e_rated', 100.0)), format="%.1f")

        with col2:
            edited_profile['location'] = st.text_input("地理位置", value=profile.get('location'))
            edited_profile['p_rated'] = st.number_input("额定功率 (MW)", min_value=1.0,
                                                        value=float(profile.get('p_rated', 25.0)), format="%.1f")

        try:
            default_date = datetime.strptime(profile.get('commission_date'), '%Y-%m-%d').date()
        except (ValueError, TypeError):
            default_date = datetime.now().date()

        edited_profile['commission_date'] = st.date_input("投运日期", value=default_date).strftime('%Y-%m-%d')

        submitted = st.form_submit_button("💾 保存档案", use_container_width=True, type="primary")
        if submitted:
            save_station_profile(edited_profile)
            st.success("电站档案已成功更新！")
            st.rerun()


def main():
    st.set_page_config(page_title="电站档案", layout="wide")

    # --- 关键修复：在此处调用 init_db() ---
    # 确保无论用户何时访问此页面，数据库和表都已存在
    init_db()

    st.title("🗄️ 电站档案与历史决策中心")
    st.markdown("---")

    # --- 电站基本档案 ---
    with st.container(border=True):
        st.header("🏢 电站基本档案")
        profile = load_station_profile()

        if profile:
            col1, col2, col3 = st.columns(3)
            col1.metric("电站名称", profile['station_name'])
            col2.metric("地理位置", profile['location'])
            col3.metric("投运日期", profile.get('commission_date', '未设置'))
            st.markdown("---")
            col1, col2 = st.columns(2)
            col1.metric("⚡ 额定容量 (E_rated)", f"{profile['e_rated']} MWh")
            col2.metric("⚡ 额定功率 (P_rated)", f"{profile['p_rated']} MW")

            with st.expander("编辑电站档案"):
                display_profile_form(profile)
        else:
            st.warning("未能加载电站档案。如果这是第一次运行，这是正常的。请尝试刷新页面。")

    st.markdown("\n\n")

    # --- 历史决策记录 ---
    with st.container(border=True):
        st.header("📈 历史决策记录")
        # 现在 load_decision_records() 将会安全执行，因为表已创建
        records_df = load_decision_records()

        if records_df.empty:
            st.info("尚无历史决策记录。请在“优化决策仪表盘”页面运行一次优化。")
        else:
            st.subheader("历史性能概览")
            total_profit = records_df['net_profit'].sum()
            total_cycles = records_df['equivalent_cycles'].sum()
            avg_profit_per_run = records_df['net_profit'].mean()

            kpi_cols = st.columns(3)
            kpi_cols[0].metric("历史总净利润", f"¥ {total_profit:,.2f}")
            kpi_cols[1].metric("累计等效循环", f"{total_cycles:.2f} 次")
            kpi_cols[2].metric("平均单次运行利润", f"¥ {avg_profit_per_run:,.2f}")

            st.subheader("决策趋势分析")
            chart_col1, chart_col2 = st.columns(2)

            with chart_col1:
                fig_profit = go.Figure()
                fig_profit.add_trace(
                    go.Scatter(x=pd.to_datetime(records_df['run_timestamp']), y=records_df['net_profit'],
                               mode='lines+markers', name='净利润'))
                fig_profit.update_layout(title="每次运行净利润趋势", xaxis_title="运行时间", yaxis_title="净利润 (元)",
                                         template="plotly_white")
                st.plotly_chart(fig_profit, use_container_width=True)

            with chart_col2:
                mode_counts = records_df['decision_mode'].value_counts()
                fig_pie = go.Figure(data=[go.Pie(labels=mode_counts.index, values=mode_counts.values, hole=.3)])
                fig_pie.update_layout(title="历史决策模式分布", template="plotly_white")
                st.plotly_chart(fig_pie, use_container_width=True)

            with st.expander("查看详细历史数据"):
                st.dataframe(records_df.style.format({
                    'net_profit': '{:,.2f}',
                    'total_throughput': '{:.2f}',
                    'equivalent_cycles': '{:.3f}'
                }), use_container_width=True)


if __name__ == "__main__":
    main()
