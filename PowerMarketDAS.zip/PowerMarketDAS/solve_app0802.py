import pyomo.environ as pyo
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objs as go
import plotly.subplots as sp


class FlowBatteryDayAheadMarketModel:
    def __init__(self, price_forecast, battery_params):
        self.price_forecast = price_forecast
        self.battery_params = battery_params
        self.hours = 24
        self.steps_per_hour = 4
        self.total_steps = self.hours * self.steps_per_hour

    def create_optimization_model(self):
        model = pyo.ConcreteModel()

        # 决策变量
        model.P_discharge = pyo.Var(
            range(self.total_steps),
            domain=pyo.NonNegativeReals
        )
        model.P_charge = pyo.Var(
            range(self.total_steps),
            domain=pyo.NonNegativeReals
        )
        model.E = pyo.Var(
            range(self.total_steps),
            domain=pyo.NonNegativeReals
        )
        model.F_in = pyo.Var(
            range(self.total_steps),
            domain=pyo.NonNegativeReals
        )
        model.F_out = pyo.Var(
            range(self.total_steps),
            domain=pyo.NonNegativeReals
        )

        # 目标函数：最大化能量套利收益
        def objective_rule(model):
            energy_revenue = sum(
                model.P_discharge[t] * self.price_forecast[t] * 0.25
                for t in range(self.total_steps)
            ) - sum(
                model.P_charge[t] * self.price_forecast[t] * 0.25
                for t in range(self.total_steps)
            )

            # 退化成本
            degradation_cost = sum(
                (model.P_charge[t] / self.battery_params['charge_efficiency'] +
                 model.P_discharge[t] * self.battery_params['discharge_efficiency']) * 0.25
                for t in range(self.total_steps)
            )

            return energy_revenue - degradation_cost

        model.objective = pyo.Objective(
            rule=objective_rule,
            sense=pyo.maximize
        )

        # 约束条件
        def energy_transfer_constraint(model, t):
            if t == 0:
                return model.E[t] == self.battery_params['initial_soc'] * self.battery_params['nominal_capacity']
            else:
                return model.E[t] == model.E[t - 1] + \
                    model.P_charge[t - 1] * self.battery_params['charge_efficiency'] * 0.25 - \
                    model.P_discharge[t - 1] / self.battery_params['discharge_efficiency'] * 0.25

        def soc_lower_constraint(model, t):
            if t == 0:
                return pyo.Constraint.Skip
            return model.E[t] >= self.battery_params['min_soc'] * self.battery_params['nominal_capacity']

        def soc_upper_constraint(model, t):
            if t == 0:
                return pyo.Constraint.Skip
            return model.E[t] <= self.battery_params['max_soc'] * self.battery_params['nominal_capacity']

        def power_charge_constraint(model, t):
            return model.P_charge[t] <= self.battery_params['max_power_in']

        def power_discharge_constraint(model, t):
            return model.P_discharge[t] <= self.battery_params['max_power_out']

        def flow_in_constraint(model, t):
            return model.F_in[t] <= self.battery_params['max_flow_in']

        def flow_out_constraint(model, t):
            return model.F_out[t] <= self.battery_params['max_flow_out']

        def flow_power_decoupling(model, t):
            return (
                model.P_charge[t] == model.F_in[t] * self.battery_params['k1'],
                model.P_discharge[t] == model.F_out[t] * self.battery_params['k2']
            )

        model.energy_transfer = pyo.Constraint(
            range(self.total_steps),
            rule=energy_transfer_constraint
        )
        model.soc_lower = pyo.Constraint(
            range(self.total_steps),
            rule=soc_lower_constraint
        )
        model.soc_upper = pyo.Constraint(
            range(self.total_steps),
            rule=soc_upper_constraint
        )
        model.power_charge = pyo.Constraint(
            range(self.total_steps),
            rule=power_charge_constraint
        )
        model.power_discharge = pyo.Constraint(
            range(self.total_steps),
            rule=power_discharge_constraint
        )
        model.flow_in = pyo.Constraint(
            range(self.total_steps),
            rule=flow_in_constraint
        )
        model.flow_out = pyo.Constraint(
            range(self.total_steps),
            rule=flow_out_constraint
        )
        model.flow_power_decoupling = pyo.Constraint(
            range(self.total_steps),
            rule=flow_power_decoupling
        )

        return model

    def solve_model(self):
        model = self.create_optimization_model()
        solver = pyo.SolverFactory('cbc')
        results = solver.solve(model, tee=True)

        return model, results


def generate_visualization(model, price_forecast, battery_params):
    # 充放电功率
    charge_power = [pyo.value(model.P_charge[t]) for t in range(len(price_forecast))]
    discharge_power = [pyo.value(model.P_discharge[t]) for t in range(len(price_forecast))]

    # 荷电状态
    soc = [pyo.value(model.E[t]) / battery_params['nominal_capacity'] for t in range(len(price_forecast))]

    # 创建子图
    fig = sp.make_subplots(rows=3, cols=1,
                           subplot_titles=('充放电功率', '电价', '荷电状态'),
                           shared_xaxes=True,
                           vertical_spacing=0.1)

    # 充放电功率曲线
    fig.add_trace(
        go.Scatter(y=charge_power, mode='lines', name='充电功率', line=dict(color='blue')),
        row=1, col=1
    )
    fig.add_trace(
        go.Scatter(y=discharge_power, mode='lines', name='放电功率', line=dict(color='red')),
        row=1, col=1
    )

    # 电价曲线
    fig.add_trace(
        go.Scatter(y=price_forecast, mode='lines', name='电价', line=dict(color='green')),
        row=2, col=1
    )

    # 荷电状态曲线
    fig.add_trace(
        go.Scatter(y=soc, mode='lines', name='荷电状态', line=dict(color='purple')),
        row=3, col=1
    )

    fig.update_layout(height=800, title_text="液流电池储能电站日前市场优化分析")
    fig.update_xaxes(title_text="时间步")
    fig.update_yaxes(title_text="功率", row=1, col=1)
    fig.update_yaxes(title_text="电价", row=2, col=1)
    fig.update_yaxes(title_text="荷电状态", row=3, col=1)

    return fig


def calculate_metrics(model, price_forecast):
    # 充放电功率
    charge_power = [pyo.value(model.P_charge[t]) for t in range(len(price_forecast))]
    discharge_power = [pyo.value(model.P_discharge[t]) for t in range(len(price_forecast))]

    # 计算收益
    charge_cost = sum(charge_power[t] * price_forecast[t] * 0.25 for t in range(len(price_forecast)))
    discharge_revenue = sum(discharge_power[t] * price_forecast[t] * 0.25 for t in range(len(price_forecast)))
    net_revenue = discharge_revenue - charge_cost

    return {
        '总充电成本': charge_cost,
        '总放电收益': discharge_revenue,
        '净收益': net_revenue,
        '总充电功率': sum(charge_power),
        '总放电功率': sum(discharge_power)
    }


def display_battery_params(battery_params):
    st.sidebar.header("电池技术参数")
    for param, value in battery_params.items():
        st.sidebar.write(f"{param}: {value}")


def main():
    st.set_page_config(page_title="液流电池储能电站日前市场优化", layout="wide")

    st.title("液流电池储能电站日前市场优化决策系统")

    # 侧边栏参数配置
    st.sidebar.header("系统参数配置")

    # 电池参数
    battery_params = {
        'initial_soc': st.sidebar.slider('初始荷电状态', 0.2, 0.8, 0.5),
        'nominal_capacity': st.sidebar.number_input('电池额定容量 (MWh)', 10, 100, 50),
        'min_soc': st.sidebar.slider('最小荷电状态', 0.1, 0.3, 0.2),
        'max_soc': st.sidebar.slider('最大荷电状态', 0.7, 0.9, 0.8),
        'charge_efficiency': st.sidebar.slider('充电效率', 0.7, 1.0, 0.9),
        'discharge_efficiency': st.sidebar.slider('放电效率', 0.7, 1.0, 0.9),
        'max_power_in': st.sidebar.number_input('最大充电功率 (MW)', 1, 20, 10),
        'max_power_out': st.sidebar.number_input('最大放电功率 (MW)', 1, 20, 10),
        'max_flow_in': st.sidebar.number_input('最大电解液输入流量', 1, 200, 100),
        'max_flow_out': st.sidebar.number_input('最大电解液输出流量', 1, 200, 100),
        'k1': st.sidebar.number_input('电解液输入流量转换系数', 0.1, 2.0, 1.0),
        'k2': st.sidebar.number_input('电解液输出流量转换系数', 0.1, 2.0, 1.0)
    }

    # 展示所有技术参数
    display_battery_params(battery_params)

    # 上传电价预测数据
    uploaded_file = st.file_uploader("上传电价预测数据", type=['csv', 'xlsx'])

    # 求解按钮
    solve_button = st.button("开始优化求解")

    if uploaded_file is not None and solve_button:
        # 读取电价数据
        price_forecast = pd.read_csv(uploaded_file)['price'].values

        # 创建模型并求解
        market_model = FlowBatteryDayAheadMarketModel(price_forecast, battery_params)
        optimal_model, solve_results = market_model.solve_model()

        # 性能指标
        metrics = calculate_metrics(optimal_model, price_forecast)

        # 结果展示
        col1, col2, col3, col4, col5 = st.columns(5)
        col1.metric("总充电成本", f"{metrics['总充电成本']:.2f}")
        col2.metric("总放电收益", f"{metrics['总放电收益']:.2f}")
        col3.metric("净收益", f"{metrics['净收益']:.2f}")
        col4.metric("总充电功率", f"{metrics['总充电功率']:.2f}")
        col5.metric("总放电功率", f"{metrics['总放电功率']:.2f}")

        # 可视化
        fig = generate_visualization(optimal_model, price_forecast, battery_params)
        st.plotly_chart(fig, use_container_width=True)


if __name__ == "__main__":
    main()