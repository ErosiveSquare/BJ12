from setuptools import setup, find_packages

setup(
    name='dayAheadMarket_priceImprove_modeChoose',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'pyomo',
        'numpy',
        'pandas',
        'streamlit',
        'plotly'
    ]
)